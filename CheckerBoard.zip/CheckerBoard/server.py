from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def main():
    return render_template("index.html", number=3, number2=3)

@app.route("/<int:number>")
def adjustable(number):
    return render_template("index.html", number=int(number/2), number2=int(number/2))

@app.route("/<int:number>/<int:number2>")
def adjustable2(number, number2):
    return render_template("index.html", number=int(number/2), number2=int(number2/2))

if __name__ == "__main__":
    app.run(debug=True)